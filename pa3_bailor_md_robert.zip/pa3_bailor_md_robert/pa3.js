$(document).ready(function(){

  $("button").click(function(){
    var val = parseInt($("input:text").val());
    if (val>20){
        $(".image" ).hide();
        $(".alert").html("Number has to be <= 20, try again with the appropriate input.").show();
    }
    else{
        $( ".image" ).hide();
        $('.math_table').html('');
        var counter = val;
        var tr = $('<tr></tr>');
        tr.append($('<td class = "outer animated">' +'</td>'));
        for (var x=1; x<=val; x++) {
            tr.append($('<td class = "outer">'+ x +'</td>'));
        }
        $('.math_table').append(tr);

        var rand_input_1 = Math.ceil(Math.random() * val);
        var rand_input_2 = Math.ceil(Math.random() * val);
        var check_input = true;

        for (var y=1; y<=val; y++) {
            tr = $('<tr></tr>');
            for (var z=1; z<= val; z++) {

                if (z==1){
                    tr.append($('<td class = "outer">'+ y +'</td>'));
              }

                if (y===rand_input_1 && z===rand_input_2 && check_input) {
                    var correct_input = y*z;
                    tr.append($('<td class = ""><input type="text" id="user_input" name="  " form="my_form" class ="tdInput"/></td>'));
                    check_input = false;
              }
              else {
                tr.append($('<td class = "inner">'+ y*z +'</td>'));}
            }

            $('.math_table').append(tr);
        }

        var even_cell = true;

        if (val % 2 != 0) {
            $("tr:even td:odd").css( "background-color", "red" );
            $("tr:even td:even").css( "background-color", "blue" );
            $("tr:odd td:odd").css( "background-color", "blue");
            $("tr:odd td:even").css( "background-color", "red" );
            even_cell = false;
        }
        else {

            $("tr td:odd").css( "background-color", "red" );
            $("tr td:even").css( "background-color", "blue" );
        }
        $('.outer').css('background-color', 'yellow');

        var switch_cell_color = true;
        var check = $("tr td:odd").css('background-color');
        var yellow = "rgb(255, 255, 0)";
        var time = setInterval(function() {

            counter -= 1;
            if (counter === 0){

                clearInterval(time);
                var key = parseInt($('#user_input').val());


                if (key === correct_input) {
                    $(".correct").html(key + " == correct input, good job!").show();
                }
                else {
                    $(".incorrect").html(key + " is incorrect, try again!").show();
                }


                var delay = setTimeout(function(){

                    $( ".correct" ).hide();
                    $( ".incorrect" ).hide();
                    $(".image").show();
                },3000)
                $( ".math_table" ).hide();           
            }

            if (counter % 4 == 0) { 
                if (even_cell) {
                    if (check === yellow && switch_cell_color) {
                        $("tr td:odd").css('background-color', 'blue');
                        $("tr td:even").css('background-color', 'red');
                        $('.outer').css('background-color', 'yellow');
                        switch_cell_color = false;
                    
                    }

                    else {
                        $("tr td:odd").css('background-color', 'red');
                        $("tr td:even").css('background-color', 'blue');
                        $('.outer').css('background-color', 'yellow');
                        switch_cell_color = true;
                    }
                }
                else {
                    if (check === yellow && switch_cell_color) {
                        $("tr:even td:odd").css('background-color', 'blue');
                        $("tr:even td:even").css('background-color', 'red');
                        $("tr:odd td:odd").css('background-color', 'red');
                        $("tr:odd td:even").css('background-color', 'blue');
                        $('.outer').css('background-color', 'yellow');
                        switch_cell_color = false;
                    
                    }

                    else {
                        $("tr:even td:odd").css('background-color', 'red');
                        $("tr:even td:even").css('background-color', 'blue');
                        $("tr:odd td:odd").css('background-color', 'blue');
                        $("tr:odd td:even").css('background-color', 'red');
                        $('.outer').css('background-color', 'yellow');
                        switch_cell_color = true;
                    }
                }
            }

        $(".timer").html(counter + " Seconds left!").show();

        }, 1000)
    }

  });

});
