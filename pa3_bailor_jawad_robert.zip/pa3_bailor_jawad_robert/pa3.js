$(document).ready(function(){

  $("button").click(function(){
    var val = parseInt($("input:text").val());
    if (val>20){
      $(".alert").html("Number has to be <= 20, try again with the appropriate input.").show();
    }

    else{
      $( ".image" ).hide();
      $(".countDown").show();
      var counter = val;
      $('.math_table').html('');
      var tr;
      tr = $('<tr></tr>');
      tr.append($('<th>' + '</th>'));
      for (var k=1; k<=val; k++) {
          tr.append($('<td class = "outer">'+ k +'</td>'));
      }
      $('.math_table').append(tr);

      var random_input = Math.ceil(Math.random()  * val);
      var check_input = true;
      for (var i=1; i<=val; i++) {
          tr = $('<tr></tr>');
          for (var j=1; j<= val; j++) {
            if (j==1){
              tr.append($('<td class = "outer">'+ i +'</td>'));
            }

            if (i === random_input && check_input) {
              var correctInput = i*j;
              tr.append($('<td class = ""><input type="text" name="  " form="my_form" class ="tdInput"/></td>'));
              check_input = false;
            }
            else {
              tr.append($('<td class = "inner">'+ i*j +'</td>'));}
          }

          $('.math_table').append(tr);
      }
      var timer = setInterval(function() {

        $("tr td:odd").css( "background-color", "green" );
        $("tr td:even").css( "background-color", "purple" );
        $('.outer').css('background-color', 'yellow');

        counter = counter - 1;
        if (counter === 0){
          clearInterval(timer);
          $( ".math_table" ).hide();
          $( ".countDown").hide();
          $( ".image").show();

        }
        $(".countDown").html(counter + " Seconds Left!").show();

      }, 1000)

    }
  });

});
